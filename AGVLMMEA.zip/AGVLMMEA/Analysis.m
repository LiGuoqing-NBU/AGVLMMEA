function [NSV,SV,Usefuldim,AllOne,AllZero]=Analysis(Mask,FrontNo,Fitness)

    EliteMask = Mask(FrontNo==1,:);
    theta = size(EliteMask,1)/size(Mask,1);
    if rand > theta
        % 局部统计
        AllOne  = all(EliteMask,1);
        AllZero = all(~EliteMask,1); 
    else
        % 全局统计
        AllOne  = all(Mask,1);
        AllZero = all(~Mask,1);
    end
    Cluster               = kmeans(Fitness',2);
    Cluster               = Cluster';
    if mean(Fitness(Cluster==1)) > mean(Fitness(Cluster==2))
        NSV      = Cluster == 2;
        SV       = Cluster == 1;
    else
        NSV      = Cluster == 1;
        SV       = Cluster == 2;
    end
    Usefuldim = NSV & ~(AllOne | AllZero);
end