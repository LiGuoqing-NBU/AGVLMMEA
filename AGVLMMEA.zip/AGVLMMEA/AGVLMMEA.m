classdef AGVLMMEA < ALGORITHM
%  <multi> <real> <large/none> <multimodal> 
    methods
        function main(Algorithm,Problem)
            %% for DQN
            num_feature = 5;
            max_act     = 3;
            inputn      = zeros(num_feature+1,1);
            outputn     = zeros(1,1);
            net         = newff(inputn,outputn,[10 10 10],{'tansig','purelin'},'trainlm');
            Memory      = [];
            action=1;
            delta=0;
            %% Calculate the fitness of each decision variable
            GlobalGV = zeros(1,Problem.D);
            REAL    = ~strcmp(Problem.encoding,'binary');
            for i = 1 : 1+4*REAL
                if REAL
                    Dec = unifrnd(repmat(Problem.lower,Problem.D,1),repmat(Problem.upper,Problem.D,1));
                else
                    Dec = ones(Problem.D,Problem.D);
                end
                Mask       = eye(Problem.D);
                Population = Problem.Evaluation(Dec.*Mask);
                GlobalGV   = GlobalGV + NDSort([Population.objs,Population.cons],inf);
            end
            GlobalGV = GlobalGV / max(GlobalGV);
            %% Population initialization
            P   = UniformPoint(Problem.N,Problem.D,'Latin');
            Dec = P.*repmat(Problem.upper-Problem.lower,Problem.N,1) + repmat(Problem.lower,Problem.N,1);
            Mask = zeros(Problem.N,Problem.D);
            for i = 1 : Problem.N
                Mask(i,TournamentSelection(2,ceil(rand*Problem.D),GlobalGV)) = 1;
            end
            Population  = Problem.Evaluation(Dec.*Mask);

            Zmax = max(Dec, [], 1);
            Zmin = min(Dec, [], 1);
            Pop  = (Dec - repmat(Zmin, Problem.N, 1)) ./ repmat(Zmax - Zmin, Problem.N, 1);  % Normalize
            K    =  2;  % Number of subpopulations
            [~, fcm_index, ~] = fcm(Pop, K);  % Apply fuzzy C-means clustering
            [~, index]    = max(fcm_index, [], 1);  % Get cluster indices

            Masks       = cell(1,K);
            Decs        = cell(1,K);
            Populations = cell(1,K);
            GV          = cell(1,K);
            FrontNo     = cell(1,K);
            CrowdDis    = cell(1,K);
            AllOne      = cell(1,K);
            AllZero     = cell(1,K);
            SV          = cell(1,K);
            NSV         = cell(1,K);
            Non0_index  = cell(1,K);
            preUsefulDim         = cell(1,K);
            UsefulDim         = cell(1,K);
            NextStep    = cell(1,K);
            for i = 1:K
                idx            = find(index == i);
                Populations{i} = Population(idx);
                Masks{i}       = Mask(idx, :);
                Decs{i}        = Dec(idx, :);
                [Populations{i}, Decs{i}, Masks{i}, FrontNo{i}, CrowdDis{i}] = EnvironmentalSelection(Populations{i}, Decs{i}, Masks{i}, length(Populations{i}));
                GV{i}          = UpdateGV(zeros(1,Problem.D),Masks{i},FrontNo{i});
                Non0_index{i}  = true(1, Problem.D);
                preUsefulDim{i}         = false(1, Problem.D);
                NextStep{i}    = Problem.D;
            end
            for i = 1 : K
                initState      = StateCal(Masks{i}, FrontNo{i}, GV{i},GlobalGV,  Masks, delta);
                Memory         = UpdateMemory(delta, Memory, action, Populations{i}, initState , Populations{i}, initState);
            end
            %% Optimization
            Gen = 0;
            while Algorithm.NotTerminated(Population)
                Gen=Gen+1;
                delta= Problem.FE/Problem.maxFE;
                % Subpopulation evolution
                for i = 1 : K
                    LastPopulation        = Populations{i};
                    LastState             = StateCal(Masks{i},FrontNo{i}, GV{i},GlobalGV,Masks,delta);
                    [action, GV{i}] = UsingNet(Problem,GlobalGV,net,Memory,LastState,max_act,Masks{i},action,FrontNo{i}, GV{i});
                    % action
                    Mating                = TournamentSelection(2,2*length(Populations{i}),FrontNo{i},-CrowdDis{i});
                    [NSV{i},SV{i},UsefulDim{i},AllOne{i},AllZero{i}]=Analysis(Masks{i},FrontNo{i},GV{i});
                    NextStep{i}     = mean(abs(UsefulDim{i} - preUsefulDim{i})) >= (1/Problem.D);
                    % exploration
                    if NextStep{i}
                        [OffDec,OffMask]  = Operator1(Problem,Decs{i}(Mating,:), Masks{i}(Mating, :),GV{i});
                        % fprintf('operator1\n');
                    else
                        [OffDec,OffMask]  = Operator2(Problem,Decs{i}(Mating,:), Masks{i}(Mating, :), GV{i},AllOne{i},UsefulDim{i});
                        % fprintf('operator2\n');
                    end
                    preUsefulDim{i} = UsefulDim{i};
                    Offspring             = Problem.Evaluation(OffDec.*OffMask);
                    Populations{i}  = [Populations{i},Offspring];
                    Decs{i}         = [Decs{i};OffDec];
                    Masks{i}        = [Masks{i};OffMask];

                    if i > 1
                        for j = 1 : i-1
                            [~,fs(j)] = min(mean(Populations{j}.objs,2));
                        end
                        R = zeros(1,Problem.D);
                        for j = 1 : i-1
                            R = R + Masks{j}(fs(j),:);
                        end
                        R(R>0) = 1;
                        dis = sum(repmat(R,length(Populations{i}),1)& Masks{i},2);
                        [Populations{i},Decs{i},Masks{i},FrontNo{i},CrowdDis{i}] = EnvironmentalSelection(Populations{i},Decs{i},Masks{i},floor(Problem.N/K),dis);
                    else
                        [Populations{i},Decs{i},Masks{i},FrontNo{i},CrowdDis{i}] = EnvironmentalSelection(Populations{i},Decs{i},Masks{i},floor(Problem.N/K));
                    end
                    %Store experience
                    CurrentState = StateCal(Masks{i},FrontNo{i}, GV{i},GlobalGV, Masks,delta);
                    Memory = UpdateMemory(delta,Memory,action,LastPopulation,LastState,Populations{i},CurrentState);
                    net    = TrainNet(Problem,net,Memory,num_feature,max_act,Gen);
                end
                if mod(Gen, 20) == 0
                    AllMasks = vertcat(Masks{:});
                    [N, D] = size(AllMasks);
                    Sparseness = sum(AllMasks(:)) / N;
                    for j = 1:D
                        varFreq = sum(AllMasks(:, j));
                        if varFreq >= N/2
                            GlobalGV(j) = max(1, GlobalGV(j) - delta * Sparseness);
                        else
                            GlobalGV(j) = GlobalGV(j) + delta * Sparseness;
                        end
                    end
                end

                %% hybrid hierarchical clustering
                if mod(ceil(Problem.FE/Problem.N),20)==0 && Gen < floor(Problem.maxFE / Problem.N * 0.95)
                    k = K;
                    %divide operation(Line103-118)
                    while 1
                        for i = 1 : K
                            [row,col,divisionFlag] = DivisionFlag(Masks{i},FrontNo{i});
                            % divisionFlag
                            if divisionFlag == 1
                                k = k+1;
                                [Populations{i},Masks{i},Decs{i},FrontNo{i},GV{i},Populations{k},Masks{k},Decs{k},FrontNo{k},GV{k}] = Divide(Populations{i},Masks{i},Decs{i},FrontNo{i},row,col);
                                preUsefulDim{k}         = UsefulDim{i};
                                [NSV{i},SV{i},UsefulDim{i},AllOne{i},AllZero{i}]=Analysis(Masks{i},FrontNo{i},GV{i});
                                [NSV{k},SV{k},UsefulDim{k},AllOne{k},AllZero{k}]=Analysis(Masks{k},FrontNo{k},GV{k});
                                NextStep{k}    = Problem.D;           
                                Non0_index{k}  = true(1, Problem.D);   
                            end
                        end
                        K = k;
                        if divisionFlag == 0
                            break;
                        end
                    end
                    % merge operation（Line120-143）
                    [ss,index]   = SubPopSimility(Populations,Masks,FrontNo);
                    while K>2 && ss>0.5
                        i = index(1);
                        j = index(2);
                        [Populations{i},Decs{i},Masks{i},FrontNo{i},CrowdDis{i}] = EnvironmentalSelection([Populations{i},Populations{j}],[Decs{i};Decs{j}],[Masks{i};Masks{j}],length(Populations{i}));
                        [NSV{i},SV{i},UsefulDim{i},AllOne{i},AllZero{i}]=Analysis(Masks{i},FrontNo{i},GV{i});
                        preUsefulDim(j)         = [];
                        UsefulDim(j)         = [];
                        Non0_index(j)  = [];  
                        Populations(j) = [];
                        Decs(j)        = [];
                        Masks(j)       = [];
                        FrontNo(j)     = [];
                        CrowdDis(j)    = [];
                        NextStep(j)    = [];
                        GV(j) = [];
                        K = K-1;
                        [ss,index]   = SubPopSimility1(Populations(1:K),Masks,FrontNo);
                    end
                    % fill operation
                    popsize = floor(Problem.N/K); %average size of each Subpopulation
                    [~,rank] = sort(SubPopRank(Populations));
                    for i = 1:K
                        len = popsize - length(Populations{rank(i)});
                        if len > 0
                            P   = UniformPoint(len,Problem.D,'Latin');
                            dec  = P.*unifrnd(repmat(Problem.lower,len,1),repmat(Problem.upper,len,1));
                            mask  = zeros(len,Problem.D);
                            F = zeros(1,Problem.D);
                            for j = 1: K
                                if j ~=i
                                    F = F + GV{rank(j)};
                                end
                            end
                            for j = 1 : len
                                mask(j,TournamentSelection(2,floor(rand*Problem.D),F)) = 1;
                            end
                            Populations{rank(i)} = [Populations{rank(i)},Problem.Evaluation(dec.*mask)];
                            Masks{rank(i)}       = [Masks{rank(i)};mask];
                            Decs{rank(i)}        = [Decs{rank(i)};dec];
                        end
                        [Populations{rank(i)},Decs{rank(i)},Masks{rank(i)},FrontNo{rank(i)},CrowdDis{rank(i)}] = EnvironmentalSelection(Populations{rank(i)},Decs{rank(i)},Masks{rank(i)},popsize);
                    end
                end
                Population = [Populations{:}];
            end
        end
    end
end