function [action, GV]  = UsingNet(Problem,globalGV,net,Memory,CurrentState,max_act,Mask,action,FrontNo,LastGV)

    output = zeros(1,max_act);
    if size(Memory,1) == 1      
    elseif rand < 0.1^(Problem.FE/Problem.maxFE) || size(Memory,1) < ceil(0.25*Problem.maxFE/100)
        action = randi([1 max_act],1);   
       
    else
        for i = 1 : max_act
            input     = [CurrentState' i]';
            output(i) = sim(net,input);
        end
        [~,action] = max(output);
    end 
  
    switch action
        case 1
            GV = globalGV;
        case 2
            GV = UpdateGV(LastGV,Mask,FrontNo);
        case 3
            GV   = 1 - globalGV;
    end
end