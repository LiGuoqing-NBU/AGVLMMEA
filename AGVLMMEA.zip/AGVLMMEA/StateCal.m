function State = StateCal(Mask, FrontNo, currentGV,globalGV, Masks, delta)


    Conv = sum(FrontNo == 1) / length(FrontNo);

    p = mean(Mask, 1);
    IntraDiv = mean(p .* (1 - p));  
    IntraDiv = IntraDiv / 0.25;

    K = length(Masks);
    D = size(Masks{1},2);
    meanVecs = zeros(K,D);
    for i=1:K
        meanVecs(i,:) = mean(Masks{i},1);
    end
    InterDiv = mean(std(meanVecs,0,1));  
    InterDiv = InterDiv / 0.5;

    GV_delta = mean(abs(currentGV - globalGV)) / D;  

    State = [
        Conv;
        IntraDiv;
        InterDiv;
        GV_delta
        delta;
    ];
end

