function [ss, index] = SubPopSimility(Populations, Masks, FrontNo)

    K = length(Populations);
    repMasks = cell(1, K);
    repObjSums = zeros(1, K);
    repNonZeroCnt = zeros(1, K);
    
    for i = 1:K
        currPop = Populations{i};
        currMasks = Masks{i};
        currFront = FrontNo{i};
        popSize = length(currPop);
    
        nonDomIdx = currFront == 1;
        objSums = sum([currPop(nonDomIdx).objs], 2);
        [minObjSum, minIdxInNonDom] = min(objSums);
        repGlobalIdx = find(nonDomIdx, 1, 'first') + minIdxInNonDom - 1;
        repMasks{i} = currMasks(repGlobalIdx, :);                
        repNonZero = (repMasks{i} ~= 0);                       
        repObjSums(i) = minObjSum;                              
        repNonZeroCnt(i) = sum(repNonZero);                     
        activation_patterns{i} = repNonZero;                     
    end

    similarity_matrix = zeros(K, K);
    for i = 1:K
        for j = i+1:K
         
            pattern_i = activation_patterns{i};
            pattern_j = activation_patterns{j};
            commonNonZero = sum(pattern_i & pattern_j);  
            minNonZero = min(repNonZeroCnt(i), repNonZeroCnt(j));  
            similarity_matrix(i, j) = commonNonZero / minNonZero;
            similarity_matrix(j, i) = similarity_matrix(i, j);  
        end
    end
    [ss, linear_idx] = max(similarity_matrix(:));
    [i_max, j_max] = ind2sub(size(similarity_matrix), linear_idx);
    index = [i_max, j_max];
end