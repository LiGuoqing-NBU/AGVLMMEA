function [OffDec,OffMask] = Operator2(Problem,ParentDec,ParentMask,Score,allone,usefuldim)

    %% Parameter setting
    [N, D] = size(ParentDec);
    Parent1Mask = ParentMask(1:end/2,:);
    Parent2Mask = ParentMask(end/2+1:end,:);
    Parent1 = ParentDec(1:floor(end/2),:);
    Parent2 = ParentDec(floor(end/2)+1:floor(end/2)*2,:);
    %% Binary variation
    OffMask = Parent1Mask;
    for i = 1 : N/2
        index1 = find(Parent1Mask(i,usefuldim)&~Parent2Mask(i,usefuldim));
        index2 = find(~Parent1Mask(i,usefuldim)&Parent2Mask(i,usefuldim));
        p1 = 1./(1+exp(-Score(usefuldim(index1))));
        p2 = 1./(1+exp(-Score(usefuldim(index2))));
        idx1 = index1(p1<rand(size(p1)));
        idx2 = index2(p2>rand(size(p2)));
        OffMask(i,usefuldim(idx1)) = 0;
        OffMask(i,usefuldim(idx2)) = 1;
    end
    %% Mutation for mask
    for i = 1 : N/2
        if rand < 0.5
            index = find(OffMask(i,usefuldim));
            index = index(TS(Score(usefuldim(index))));
            OffMask(i,index) = 0;
        else
            index = find(~OffMask(i,usefuldim));
            index = index(TS(-Score(usefuldim(index))));
            OffMask(i,index) = 1;
        end
    end
    for i = 1 : N/2
        OffMask(i, allone) = 1;
    end
    activeDim = usefuldim|allone;
    for i = 1 : N/2
        OffDec(i,:)  = DecOptimal(Parent1(i,:),Parent2(i, :),Problem,activeDim);
    end
end

function Offspring = DecOptimal(Parent1,Parent2,Problem, Non0_index)
% Genetic operators for real and integer variables
    [proC,disC,proM,disM] = deal(1,20,1,20);
    lower = Problem.lower;
    upper = Problem.upper;

    %% Simulated binary crossover
    [N,D] = size(Parent1);
    beta  = zeros(N,D);
    mu    = rand(N,D);
    beta(mu<=0.5) = (2*mu(mu<=0.5)).^(1/(disC+1));
    beta(mu>0.5)  = (2-2*mu(mu>0.5)).^(-1/(disC+1));
    beta = beta.*(-1).^randi([0,1],N,D);
    beta(rand(N,D)<0.5) = 1;
    beta(repmat(rand(N,1)>proC,1,D)) = 1;
    Offspring = (Parent1+Parent2)/2+beta.*(Parent1-Parent2)/2;

    %% Polynomial mutation
    Lower = repmat(lower,N,1);
    Upper = repmat(upper,N,1);
    % set the probability of mutation and variable to be mutated
    Site  = rand(N,D) < proM/sum(Non0_index);

    mu    = rand(N,D);
    temp  = Non0_index & Site & mu<=0.5;
    Offspring       = min(max(Offspring,Lower),Upper);
    Offspring(temp) = Offspring(temp)+(Upper(temp)-Lower(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
        (1-(Offspring(temp)-Lower(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1))-1);
    temp = Non0_index & Site & mu>0.5;
    Offspring(temp) = Offspring(temp)+(Upper(temp)-Lower(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
        (1-(Upper(temp)-Offspring(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)));
end

function index = TS(Fitness)
% Binary tournament selection

    if isempty(Fitness)
        index = [];
    else
        index = TournamentSelection(2,1,Fitness);
    end
end
