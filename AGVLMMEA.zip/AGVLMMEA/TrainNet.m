function net = TrainNet(Problem,net,Memory,num_feature,max_act,Gen)

    inputn  = Memory(:,1:num_feature+1)'; 
    outputn = Memory(:,num_feature+2)';  
    net.trainParam.epochs = 100;    
    net.trainParam.lr     = 0.001;         
    net.trainParam.goal   = 0.001;       
    net.trainParam.showWindow = 0;
    output = zeros(1,max_act);
    alpha  = 0.1;

    if size(Memory,1) == ceil(0.25*Problem.maxFE/100)
        net = newff(inputn,outputn,[10 10 10],{'tansig','purelin'},'trainlm'); 
    end
    if size(Memory,1) > ceil(0.25*Problem.maxFE/100) && mod(Gen, 50) == 0
        idx = randperm(size(Memory,1), 200);
        MTrain = Memory(idx,:);
        for i = 1 : size(MTrain,1)
            for j = 1 : max_act
                input = [MTrain(i,(num_feature+3):end) j]';
                output(j) = sim(net,input);
            end
            MTrain(i,num_feature+2) = MTrain(i,num_feature+2) + alpha*max(output);
        end
        inputn  = MTrain(:,1:num_feature+1)';
        outputn = MTrain(:,num_feature+2)';
        net     = train(net,inputn,outputn);
    end
end