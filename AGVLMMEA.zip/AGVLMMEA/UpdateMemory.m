function Memory = UpdateMemory(delta,Memory,action,LastPopulation,LastState,Population,CurrentState)

    LastPopulationHV = HV(LastPopulation,max([LastPopulation.objs;Population.objs]));
    PopulationHV     = HV(Population,max([LastPopulation.objs;Population.objs]));
    delta_Conv           = (PopulationHV - LastPopulationHV)/LastPopulationHV;
    delta_IntraDiv = CurrentState(2) - LastState(2);
    delta_InterDiv = CurrentState(3) - LastState(3);

    factor = 500; 
    R1 = max(min(delta_Conv * factor, 1), -1);
    R2 = max(min(delta_IntraDiv * factor, 1), -1);
    R3 = max(min(delta_InterDiv * factor, 1), -1);
    

    if delta < 0.3       
        weights = [0.3, 0.4, 0.3]; 
    elseif delta < 0.7   
        weights = [0.5, 0.3, 0.2];
    else                 
        weights = [0.7, 0.2, 0.1]; 
    end

    reward = weights(1)*R1 + weights(2)*R2 + weights(3)*R3;
    
    NewMemory = [LastState', action, reward, CurrentState'];
    Memory = [Memory; NewMemory];

    if size(Memory,1) > 10000
        Memory(1,:) = [];
    end
end